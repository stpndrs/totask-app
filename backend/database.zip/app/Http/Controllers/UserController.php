<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;

class UserController extends Controller
{
    public function update(Request $request) {
        $user = $request->user();

        $validate = Validator::make($request->all(), [
            'username' => 'required',
            'name' => 'required',
            'email' => 'required|email'
        ]);

        $password = $user->password;
        if ($request->password) {
            $password = bcrypt($request->password);
        }

        $pp = null;
        if ($request->file('profile_image')) {
            $p = $request->file('profile_image');
            $pp = $p->getClientOriginalName();
            $p->storeAs('public/pp', $pp);
            if ($user->profile_image) {
                Storage::delete('storage/pp/' . $user->profile_image);
            }
        }

        $user->update([
            'username' => $request->username,
            'name' => $request->name,
            'email' => $request->email,
            'password' => $password,
            'profile_image' => $pp,
        ]);

        return $this->success(['message' => 'Update profile success', 'data' => $user]);
    }
}
